const getCookieBtn = document.getElementById('get-cookies');
const cookieBody = document.getElementById('cookie-table-body');
getCookieBtn.addEventListener('click', async () => {
    browser.runtime.sendMessage({type: 'GET_COOKIES'});
});

function updateCookieTable(cookies) {
    while (cookieBody.firstChild) {
        cookieBody.removeChild(cookieBody.lastChild);
    }
    cookies.forEach(function(cookie){
        const tr = document.createElement('tr');
        const tdName = document.createElement('td');
        const tdValue = document.createElement('td');
        tdName.textContent = cookie.name;
        tdValue.textContent = cookie.value;
        tr.appendChild(tdName);
        tr.appendChild(tdValue);
        cookieBody.appendChild(tr);
    });
}

browser.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    switch(message.type) {
        case 'COOKIES':
            updateCookieTable(message.data)
            break;
        default:
            console.log('unknown message')
    }
});


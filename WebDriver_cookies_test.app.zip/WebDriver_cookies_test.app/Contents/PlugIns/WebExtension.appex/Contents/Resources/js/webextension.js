/* eslint max-statements: [2, 44], complexity: [2, 7] */
/* global chrome, PLUGIN_VERSIONS, console */
// Plugin functionality that is built with the web extension architecture.
// This is shared amongst:
// - Google Chrome
// - Mozilla Firefox
// - Microsoft Chromium Edge
async function getCurrentUrlAllCookies(request, sender, sendResponse) {
    const currentTab = await browser.tabs.query({active: true, currentWindow: true});
    const currentUrl = new URL(currentTab[0].url);
    const cookies = await browser.cookies.getAll({'url': currentUrl.origin});
    browser.runtime.sendMessage({type: 'COOKIES', data: cookies})
    console.log(cookies);
}

async function messageListener(request, sender, sendResponse) {
    switch (request.type) {
        case 'GET_COOKIES':
            await getCurrentUrlAllCookies(request, sender, sendResponse);
            break;
        default:
            console.log('unknown message');
    }
}

browser.runtime.onMessage.addListener(messageListener);
